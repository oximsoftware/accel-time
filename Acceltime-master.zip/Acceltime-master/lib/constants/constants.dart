class Constants {
  static String activation_data = "Accesspoint_Activated";
  static String login_data = "Login_Activated";
  static String roleType = "RoleType";
  static const String base_url =
      "http://103.214.233.181/AcceltimeWebAPI/api/Acceltime/Mobile/v1/";
}
